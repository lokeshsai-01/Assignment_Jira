package org.example;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import java.util.Scanner;


public class Main {

    private static void getIssue(String issueId){

        HttpResponse<JsonNode> response = null;
        try {
            String url ="https://lokeshstriver.atlassian.net/rest/api/3/issue/";
            response = Unirest.get(url+issueId)
                    .basicAuth("lokeshstriver@gmail.com", "ATATT3xFfGF0AMNbSD23L5S2Loy3oXo6OhNGDLkrQppflnO7P2P0WHGni0JfSHFuKga_ZleufWODSfcjlfQMBokn7Jzv5ZieAKzMCf4yolhz6ZT2T9Uu7COts2Nq__-eI-WP79_Ju2-fFyS591Tc7ww-Lu6lNOsFF2zIrznaCJOudHDcY_KnJm4=F3327211")
                    .header("Accept", "application/json")
                    .asJson();
        } catch (UnirestException e) {
            throw new RuntimeException(e);
        }

        System.out.println(response.getBody());
    }

    private static void deleteIssue(String IssueId){
        HttpResponse<String> response = null;
        try {
            response = Unirest.delete("https://lokeshstriver.atlassian.net/rest/api/3/issue/"+IssueId)
                    .basicAuth("lokeshstriver@gmail.com", "ATATT3xFfGF0AMNbSD23L5S2Loy3oXo6OhNGDLkrQppflnO7P2P0WHGni0JfSHFuKga_ZleufWODSfcjlfQMBokn7Jzv5ZieAKzMCf4yolhz6ZT2T9Uu7COts2Nq__-eI-WP79_Ju2-fFyS591Tc7ww-Lu6lNOsFF2zIrznaCJOudHDcY_KnJm4=F3327211")
                    .asString();
        } catch (UnirestException e) {
            throw new RuntimeException(e);
        }

        System.out.println(response.getBody());
    }
    private static void getUserProfile(){
        HttpResponse<JsonNode> response = null;
        try {
            response = Unirest.get("https://lokeshstriver.atlassian.net/rest/api/3/project/search")
                    .basicAuth("lokeshstriver@gmail.com", "ATATT3xFfGF0AMNbSD23L5S2Loy3oXo6OhNGDLkrQppflnO7P2P0WHGni0JfSHFuKga_ZleufWODSfcjlfQMBokn7Jzv5ZieAKzMCf4yolhz6ZT2T9Uu7COts2Nq__-eI-WP79_Ju2-fFyS591Tc7ww-Lu6lNOsFF2zIrznaCJOudHDcY_KnJm4=F3327211")
                    .header("Accept", "application/json")
                    .asJson();
        } catch (UnirestException e) {
            throw new RuntimeException(e);
        }

        System.out.println(response.getBody());
    }

    private static void deleteProject(String s){
        HttpResponse<String> response = null;
        try {
            response = Unirest.delete("https://lokeshstriver.atlassian.net/rest/api/3/project/"+s)
                    .basicAuth("lokeshstriver@gmail.com", "ATATT3xFfGF0AMNbSD23L5S2Loy3oXo6OhNGDLkrQppflnO7P2P0WHGni0JfSHFuKga_ZleufWODSfcjlfQMBokn7Jzv5ZieAKzMCf4yolhz6ZT2T9Uu7COts2Nq__-eI-WP79_Ju2-fFyS591Tc7ww-Lu6lNOsFF2zIrznaCJOudHDcY_KnJm4=F3327211")
                    .asString();
        } catch (UnirestException e) {
            throw new RuntimeException(e);
        }

        System.out.println(response.getBody());
    }

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        outerloop : while (true){
            System.out.println("***********************************************************");
            System.out.println("Select an option");
            System.out.println("1-Display Projects data");
            System.out.println("2-Delete project");
            System.out.println("3-Display Issues");
            System.out.println("4-Delete Issue");
            System.out.println("q-To quit");
            String ch=sc.nextLine();

            switch (ch) {
                case "1":
                    getUserProfile();
                    break;
                case "2":
                    System.out.println("Provide ProjectID");
                    String s=sc.nextLine();
                    deleteProject(s);
                    break;
                case "3":
                    System.out.println("Provide IssueID");
                    String z=sc.nextLine();
                    getIssue(z);
                    break;
                case "4":
                    System.out.println("Provide IssueID");
                    String k=sc.nextLine();
                    deleteIssue(k);
                    break;
                case "q":
                    break outerloop;

            }
        }
    }
}
